var s=89;
if(s%2==0)
{
    console.log("EVEn NUM");
}
else{
    console.log("odd num");
}