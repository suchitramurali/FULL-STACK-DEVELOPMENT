var x=3;
var y=500;
var s=x+y;
console.log(s);