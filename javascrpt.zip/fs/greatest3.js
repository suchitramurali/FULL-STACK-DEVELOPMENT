var e=90;
var w=65;
var q=81;
if(e>w)
{
    if(e>q)
    {console.log(e)}
    else{console.log(q);
    }
}
else{
if(w>q)
{
    console.log(w);
}
    else{
        console.log(q);
    }

}