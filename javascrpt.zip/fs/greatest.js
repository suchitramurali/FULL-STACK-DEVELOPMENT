var e=67;
var w=87;
if(e>w)
{
    console.log(e);
}
else{
    console.log(w);
}